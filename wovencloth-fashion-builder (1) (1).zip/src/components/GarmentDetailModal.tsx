import { useEffect, useState } from "react";
import { X } from "lucide-react";
import type { Garment } from "@/src/data/garments";

interface GarmentDetailModalProps {
  garment: Garment | null;
  onClose: () => void;
  onAddToBag: (garment: Garment, size: string) => void;
  onPullForShoot: (garmentId: string) => void;
}

export function GarmentDetailModal({
  garment,
  onClose,
  onAddToBag,
  onPullForShoot,
}: GarmentDetailModalProps) {
  const [selectedSize, setSelectedSize] = useState<string>("M");
  const [imageError, setImageError] = useState(false);

  useEffect(() => {
    if (garment) {
      setSelectedSize(garment.sizes.includes("M") ? "M" : garment.sizes[0]);
      setImageError(false);
    }
  }, [garment]);

  useEffect(() => {
    if (!garment) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [garment, onClose]);

  if (!garment) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="garment-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative grid w-full max-w-4xl grid-cols-1 overflow-hidden bg-[var(--paper)] text-[var(--ink)] shadow-2xl md:grid-cols-2">
        <button
          type="button"
          onClick={onClose}
          aria-label="Close garment details"
          className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center border border-[var(--line)] bg-[var(--paper)] text-[var(--ink)] transition-colors hover:bg-[var(--ink)] hover:text-[var(--paper)]"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="relative aspect-[4/3] bg-[#E8E5DC] md:aspect-auto md:min-h-[460px]">
          {!imageError ? (
            <img
              src={garment.image}
              alt={garment.name}
              referrerPolicy="no-referrer"
              onError={() => setImageError(true)}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-[#EAE8E1] to-[#DAD6CB] p-8 text-center">
              <span className="font-mono-tabular text-xs text-[var(--muted)]">{garment.sku}</span>
              <span className="mt-2 font-display text-2xl">{garment.name}</span>
            </div>
          )}
        </div>

        <div className="flex flex-col justify-between p-6 sm:p-8">
          <div className="space-y-5">
            <div className="flex flex-wrap items-center gap-2 text-xs text-[var(--muted)]">
              <span>{garment.category}</span>
              <span aria-hidden="true">·</span>
              <span>{garment.material}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-tabular">{garment.sku}</span>
            </div>

            <div>
              <h2
                id="garment-modal-title"
                className="font-display text-3xl font-medium leading-tight tracking-tight"
              >
                {garment.name}
              </h2>
              <p className="mt-2 font-mono-tabular text-lg font-medium text-[var(--ink)]">
                ${garment.price.toLocaleString()}
              </p>
            </div>

            <p className="text-sm leading-relaxed text-[var(--muted)]">{garment.description}</p>

            <div className="border-t border-[var(--line)] pt-4">
              <div className="flex items-center justify-between text-xs text-[var(--muted)]">
                <span>Textile Specification</span>
                <span className="text-[var(--ink)]">{garment.weaveNote}</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-xs text-[var(--muted)]">
                <span>Availability</span>
                <span className="text-[var(--blue)]">{garment.edition}</span>
              </div>
            </div>

            <div className="space-y-2.5 pt-2">
              <span className="block text-xs font-medium text-[var(--muted)]">Select Size</span>
              <div className="flex flex-wrap gap-2">
                {garment.sizes.map((size) => {
                  const active = selectedSize === size;
                  return (
                    <button
                      key={size}
                      type="button"
                      onClick={() => setSelectedSize(size)}
                      className={`h-10 min-w-[44px] border px-3 font-mono-tabular text-xs font-medium transition-colors ${
                        active
                          ? "border-[var(--ink)] bg-[var(--ink)] text-[var(--paper)]"
                          : "border-[var(--line)] bg-transparent text-[var(--ink)] hover:border-[var(--ink)]"
                      }`}
                    >
                      {size}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-3 border-t border-[var(--line)] pt-5">
            <button
              type="button"
              onClick={() => {
                onAddToBag(garment, selectedSize);
                onClose();
              }}
              className="btn flex-1 justify-between"
            >
              Add to bag <b>→</b>
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onPullForShoot(garment.id);
              }}
              className="h-[52px] border border-[var(--line)] px-4 text-xs font-semibold text-[var(--ink)] transition-colors hover:border-[var(--ink)] whitespace-nowrap shrink-0"
            >
              Pull for shoot
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
