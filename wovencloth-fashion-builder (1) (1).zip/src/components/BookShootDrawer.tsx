import { useEffect, useState, type FormEvent } from "react";
import { X, Check } from "lucide-react";
import { GARMENTS } from "@/src/data/garments";

interface BookShootDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  initialGarmentIds?: string[];
}

type ShootType = "Editorial Campaign" | "Lookbook Pull" | "Private Fitting";

export function BookShootDrawer({
  isOpen,
  onClose,
  initialGarmentIds = [],
}: BookShootDrawerProps) {
  const [shootType, setShootType] = useState<ShootType>("Editorial Campaign");
  const [date, setDate] = useState("2026-12-04");
  const [slot, setSlot] = useState("10:00 Morning Light");
  const [selectedIds, setSelectedIds] = useState<string[]>(initialGarmentIds);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [notes, setNotes] = useState("");
  const [confirmedRef, setConfirmedRef] = useState<string | null>(null);

  useEffect(() => {
    if (initialGarmentIds.length > 0) {
      setSelectedIds((prev) => Array.from(new Set([...prev, ...initialGarmentIds])));
    }
  }, [initialGarmentIds]);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const toggleGarment = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id],
    );
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const code = `MA-${Math.floor(2040 + Math.random() * 890)}`;
    setConfirmedRef(code);
  };

  const handleReset = () => {
    setConfirmedRef(null);
    setName("");
    setEmail("");
    setNotes("");
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/65"
      role="dialog"
      aria-modal="true"
      aria-labelledby="book-shoot-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative flex h-full w-full max-w-xl flex-col overflow-y-auto bg-[var(--paper)] text-[var(--ink)] shadow-2xl">
        <div className="flex items-center justify-between border-b border-[var(--line)] px-6 py-5 sm:px-8">
          <div>
            <p className="text-xs text-[var(--muted)]">Studio Calendar · Paris &amp; Kyoto Pulls</p>
            <h2 id="book-shoot-title" className="font-display text-2xl font-medium tracking-tight">
              Book a Shoot
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close shoot booking drawer"
            className="flex h-10 w-10 items-center justify-center border border-[var(--line)] text-[var(--ink)] transition-colors hover:bg-[var(--ink)] hover:text-[var(--paper)]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {confirmedRef ? (
          <div className="flex flex-1 flex-col justify-between p-6 sm:p-8">
            <div className="space-y-6">
              <div className="flex h-11 w-11 items-center justify-center bg-[var(--ink)] text-[var(--paper)]">
                <Check className="h-5 w-5" />
              </div>
              <div className="space-y-2">
                <p className="font-mono-tabular text-xs text-[var(--blue)]">
                  Reservation {confirmedRef} · Confirmed
                </p>
                <h3 className="font-display text-3xl font-medium">
                  Studio session reserved for {name || "your team"}.
                </h3>
                <p className="text-sm leading-relaxed text-[var(--muted)]">
                  Our archive coordinator will prepare your selected garments on the studio rail
                  ahead of your arrival and send call-sheet coordinates to {email || "your email"}.
                </p>
              </div>

              <dl className="divide-y divide-[var(--line)] border-y border-[var(--line)] text-sm">
                <div className="flex justify-between py-3">
                  <dt className="text-[var(--muted)]">Format</dt>
                  <dd className="font-medium">{shootType}</dd>
                </div>
                <div className="flex justify-between py-3">
                  <dt className="text-[var(--muted)]">Date &amp; Window</dt>
                  <dd className="font-mono-tabular">
                    {date} · {slot}
                  </dd>
                </div>
                <div className="flex justify-between py-3">
                  <dt className="text-[var(--muted)]">Garment Pulls</dt>
                  <dd className="font-mono-tabular">{selectedIds.length} pieces</dd>
                </div>
              </dl>
            </div>

            <div className="pt-8">
              <button type="button" onClick={handleReset} className="btn">
                Return to atelier <b>→</b>
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-1 flex-col justify-between p-6 sm:p-8">
            <div className="space-y-7">
              <fieldset className="space-y-2.5">
                <legend className="text-xs font-medium text-[var(--muted)]">
                  Session Format
                </legend>
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                  {(["Editorial Campaign", "Lookbook Pull", "Private Fitting"] as const).map(
                    (type) => {
                      const active = shootType === type;
                      return (
                        <button
                          key={type}
                          type="button"
                          onClick={() => setShootType(type)}
                          className={`border px-3 py-2.5 text-left text-xs font-medium transition-colors ${
                            active
                              ? "border-[var(--ink)] bg-[var(--ink)] text-[var(--paper)]"
                              : "border-[var(--line)] bg-transparent text-[var(--ink)] hover:border-[var(--ink)]"
                          }`}
                        >
                          {type}
                        </button>
                      );
                    },
                  )}
                </div>
              </fieldset>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <label className="block space-y-1.5">
                  <span className="text-xs font-medium text-[var(--muted)]">Preferred Date</span>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full border border-[var(--line)] bg-white/70 px-3 py-2.5 font-mono-tabular text-sm text-[var(--ink)]"
                  />
                </label>

                <label className="block space-y-1.5">
                  <span className="text-xs font-medium text-[var(--muted)]">Lighting Window</span>
                  <select
                    value={slot}
                    onChange={(e) => setSlot(e.target.value)}
                    className="w-full border border-[var(--line)] bg-white/70 px-3 py-2.5 text-sm text-[var(--ink)]"
                  >
                    <option value="10:00 Morning Light">10:00 · Morning Light</option>
                    <option value="14:30 Studio Softbox">14:30 · Studio Softbox</option>
                    <option value="17:30 Twilight Rim">17:30 · Twilight Rim</option>
                  </select>
                </label>
              </div>

              <div className="space-y-2.5">
                <div className="flex items-baseline justify-between">
                  <span className="text-xs font-medium text-[var(--muted)]">
                    Garments to Pull on Rack
                  </span>
                  <span className="font-mono-tabular text-xs text-[var(--muted)]">
                    {selectedIds.length} selected
                  </span>
                </div>
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {GARMENTS.map((garment) => {
                    const checked = selectedIds.includes(garment.id);
                    return (
                      <button
                        key={garment.id}
                        type="button"
                        onClick={() => toggleGarment(garment.id)}
                        className={`flex items-center gap-3 border p-2 text-left transition-colors ${
                          checked
                            ? "border-[var(--ink)] bg-white"
                            : "border-[var(--line)] bg-transparent hover:border-[var(--muted)]"
                        }`}
                      >
                        <img
                          src={garment.image}
                          alt={garment.name}
                          referrerPolicy="no-referrer"
                          className="h-11 w-14 shrink-0 object-cover bg-[#E6E4DC]"
                        />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-xs font-medium text-[var(--ink)]">
                            {garment.name}
                          </p>
                          <p className="truncate font-mono-tabular text-[11px] text-[var(--muted)]">
                            {garment.sku}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <label className="block space-y-1.5">
                  <span className="text-xs font-medium text-[var(--muted)]">
                    Stylist / Client Name
                  </span>
                  <input
                    type="text"
                    required
                    placeholder="Clara Moreau"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full border border-[var(--line)] bg-white/70 px-3 py-2.5 text-sm text-[var(--ink)] placeholder:text-[var(--muted)]/60"
                  />
                </label>

                <label className="block space-y-1.5">
                  <span className="text-xs font-medium text-[var(--muted)]">Studio Email</span>
                  <input
                    type="email"
                    required
                    placeholder="studio@publication.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full border border-[var(--line)] bg-white/70 px-3 py-2.5 text-sm text-[var(--ink)] placeholder:text-[var(--muted)]/60"
                  />
                </label>
              </div>

              <label className="block space-y-1.5">
                <span className="text-xs font-medium text-[var(--muted)]">
                  Lighting &amp; Sizing Notes
                </span>
                <textarea
                  rows={2}
                  placeholder="Sample sizes, backdrop preferences, or iridescent silk swatch requests."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full border border-[var(--line)] bg-white/70 px-3 py-2.5 text-sm text-[var(--ink)] placeholder:text-[var(--muted)]/60"
                />
              </label>
            </div>

            <div className="mt-8 flex items-center justify-between gap-4 border-t border-[var(--line)] pt-5">
              <span className="text-xs text-[var(--muted)]">Response within 4 business hours</span>
              <button type="submit" className="btn">
                Confirm shoot request <b>→</b>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
