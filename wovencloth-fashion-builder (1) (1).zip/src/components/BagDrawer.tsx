import { useEffect, useState, type FormEvent } from "react";
import { X, Plus, Minus, Trash2, Check } from "lucide-react";
import type { Garment } from "@/src/data/garments";

export interface BagItem {
  garment: Garment;
  size: string;
  quantity: number;
}

interface BagDrawerProps {
  isOpen: boolean;
  items: BagItem[];
  onClose: () => void;
  onUpdateQuantity: (garmentId: string, size: string, delta: number) => void;
  onRemove: (garmentId: string, size: string) => void;
  onClearBag: () => void;
}

export function BagDrawer({
  isOpen,
  items,
  onClose,
  onUpdateQuantity,
  onRemove,
  onClearBag,
}: BagDrawerProps) {
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [customerName, setCustomerName] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [shippingAddress, setShippingAddress] = useState("");
  const [orderNumber, setOrderNumber] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.garment.price * item.quantity, 0);
  const courierFee = subtotal >= 1200 || subtotal === 0 ? 0 : 35;
  const total = subtotal + courierFee;

  const handleCheckout = (e: FormEvent) => {
    e.preventDefault();
    const id = `MA-${Math.floor(1040 + Math.random() * 900)}`;
    setOrderNumber(id);
    onClearBag();
    setCheckoutOpen(false);
  };

  const handleDone = () => {
    setOrderNumber(null);
    setCustomerName("");
    setCustomerEmail("");
    setShippingAddress("");
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/65"
      role="dialog"
      aria-modal="true"
      aria-labelledby="bag-drawer-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative flex h-full w-full max-w-md flex-col bg-[var(--paper)] text-[var(--ink)] shadow-2xl">
        <div className="flex items-center justify-between border-b border-[var(--line)] px-6 py-5">
          <div>
            <p className="text-xs text-[var(--muted)]">Atelier Dispatch · Insured Courier</p>
            <h2 id="bag-drawer-title" className="font-display text-2xl font-medium">
              Shopping Bag
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close shopping bag"
            className="flex h-10 w-10 items-center justify-center border border-[var(--line)] text-[var(--ink)] transition-colors hover:bg-[var(--ink)] hover:text-[var(--paper)]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {orderNumber ? (
          <div className="flex flex-1 flex-col justify-between p-6">
            <div className="space-y-5">
              <div className="flex h-11 w-11 items-center justify-center bg-[var(--ink)] text-[var(--paper)]">
                <Check className="h-5 w-5" />
              </div>
              <p className="font-mono-tabular text-xs text-[var(--blue)]">
                Order {orderNumber} Confirmed — Preparing Garment Bag
              </p>
              <h3 className="font-display text-3xl font-medium">
                Thank you, {customerName || "client"}.
              </h3>
              <p className="text-sm leading-relaxed text-[var(--muted)]">
                Each garment is steamed, hung in breathable cotton canvas, and dispatched to{" "}
                {shippingAddress || "your address"}. Receipt sent to {customerEmail}.
              </p>
            </div>
            <button type="button" onClick={handleDone} className="btn">
              Continue browsing <b>→</b>
            </button>
          </div>
        ) : items.length === 0 ? (
          <div className="flex flex-1 flex-col items-start justify-center p-6">
            <p className="font-display text-2xl font-medium">Your garment bag is empty.</p>
            <p className="mt-2 text-sm text-[var(--muted)]">
              Explore the Autumn / Winter collection or book a private studio shoot pull.
            </p>
            <button type="button" onClick={onClose} className="btn mt-6">
              Browse garments <b>→</b>
            </button>
          </div>
        ) : (
          <>
            <div className="flex-1 divide-y divide-[var(--line)] overflow-y-auto px-6">
              {items.map((item) => (
                <div
                  key={`${item.garment.id}-${item.size}`}
                  className="flex gap-4 py-5"
                >
                  <img
                    src={item.garment.image}
                    alt={item.garment.name}
                    referrerPolicy="no-referrer"
                    className="h-24 w-20 shrink-0 object-cover bg-[#E8E5DC]"
                  />
                  <div className="flex min-w-0 flex-1 flex-col justify-between">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium text-[var(--ink)]">
                          {item.garment.name}
                        </p>
                        <p className="mt-0.5 text-xs text-[var(--muted)]">
                          Size {item.size} · {item.garment.sku}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onRemove(item.garment.id, item.size)}
                        aria-label={`Remove ${item.garment.name}`}
                        className="p-1 text-[var(--muted)] transition-colors hover:text-[var(--ink)]"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>

                    <div className="mt-3 flex items-center justify-between">
                      <div className="inline-flex items-center border border-[var(--line)]">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.garment.id, item.size, -1)}
                          aria-label="Decrease quantity"
                          className="flex h-8 w-8 items-center justify-center text-[var(--ink)] hover:bg-black/5"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="w-8 text-center font-mono-tabular text-xs">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.garment.id, item.size, 1)}
                          aria-label="Increase quantity"
                          className="flex h-8 w-8 items-center justify-center text-[var(--ink)] hover:bg-black/5"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                      <span className="font-mono-tabular text-sm font-medium">
                        ${(item.garment.price * item.quantity).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-[var(--line)] p-6">
              {checkoutOpen ? (
                <form onSubmit={handleCheckout} className="space-y-3">
                  <input
                    type="text"
                    required
                    placeholder="Full Name"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full border border-[var(--line)] bg-white/80 px-3 py-2 text-sm"
                  />
                  <input
                    type="email"
                    required
                    placeholder="Email for courier tracking"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    className="w-full border border-[var(--line)] bg-white/80 px-3 py-2 text-sm"
                  />
                  <input
                    type="text"
                    required
                    placeholder="Delivery Address & Postal Code"
                    value={shippingAddress}
                    onChange={(e) => setShippingAddress(e.target.value)}
                    className="w-full border border-[var(--line)] bg-white/80 px-3 py-2 text-sm"
                  />
                  <div className="flex items-center justify-between pt-2">
                    <button
                      type="button"
                      onClick={() => setCheckoutOpen(false)}
                      className="text-xs font-medium text-[var(--muted)] hover:text-[var(--ink)]"
                    >
                      Back to summary
                    </button>
                    <button type="submit" className="btn">
                      Place order (${total.toLocaleString()}) <b>→</b>
                    </button>
                  </div>
                </form>
              ) : (
                <div className="space-y-4">
                  <div className="space-y-1.5 text-sm">
                    <div className="flex justify-between text-[var(--muted)]">
                      <span>Subtotal</span>
                      <span className="font-mono-tabular">${subtotal.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-[var(--muted)]">
                      <span>Insured Courier (Complimentary over $1,200)</span>
                      <span className="font-mono-tabular">
                        {courierFee === 0 ? "Complimentary" : `$${courierFee}`}
                      </span>
                    </div>
                    <div className="flex justify-between border-t border-[var(--line)] pt-2 font-medium text-[var(--ink)]">
                      <span>Total</span>
                      <span className="font-mono-tabular">${total.toLocaleString()}</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCheckoutOpen(true)}
                    className="btn w-full justify-between"
                  >
                    Proceed to checkout <b>→</b>
                  </button>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
