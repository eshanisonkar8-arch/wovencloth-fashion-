import { WovenCloth, type WovenClothVariant } from "@/src/shaders/woven-cloth/WovenCloth";

export interface SceneProps {
  variant?: WovenClothVariant;
  hue?: number;
  saturation?: number;
  brightness?: number;
  className?: string;
}

export function Scene({
  variant = "iridescent",
  hue = 0,
  saturation = 1.0,
  brightness = 1.0,
  className = "",
}: SceneProps) {
  return (
    <div className={`shader-frame ${className}`.trim()}>
      <WovenCloth
        variant={variant}
        hue={hue}
        saturation={saturation}
        brightness={brightness}
      />
    </div>
  );
}
