import { useEffect, useMemo, useState, type MouseEvent } from "react";
import { Maximize2, X } from "lucide-react";
import { GARMENTS, type Garment, type GarmentCategory } from "@/src/data/garments";
import { Scene } from "@/src/components/Scene";
import { BookShootDrawer } from "@/src/components/BookShootDrawer";
import { GarmentDetailModal } from "@/src/components/GarmentDetailModal";
import { BagDrawer, type BagItem } from "@/src/components/BagDrawer";

const CATEGORIES: readonly GarmentCategory[] = [
  "All",
  "Outerwear",
  "Silk & Shirts",
  "Tailoring",
];

export default function App() {
  const [category, setCategory] = useState<GarmentCategory>("All");
  const [selectedGarment, setSelectedGarment] = useState<Garment | null>(null);
  const [bagItems, setBagItems] = useState<BagItem[]>([]);
  const [bagOpen, setBagOpen] = useState(false);
  const [shootOpen, setShootOpen] = useState(false);
  const [shootGarmentIds, setShootGarmentIds] = useState<string[]>([]);
  const [silkFullscreen, setSilkFullscreen] = useState(false);
  const [brokenImages, setBrokenImages] = useState<Record<string, boolean>>({});

  // Listen for the custom "book-shoot" event dispatched by #book-shoot button
  useEffect(() => {
    const handleBookShootEvent = () => {
      setShootOpen(true);
    };
    document.addEventListener("book-shoot", handleBookShootEvent);
    return () => document.removeEventListener("book-shoot", handleBookShootEvent);
  }, []);

  useEffect(() => {
    if (!silkFullscreen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSilkFullscreen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [silkFullscreen]);

  const filteredGarments = useMemo(() => {
    if (category === "All") return GARMENTS;
    return GARMENTS.filter((item) => item.category === category);
  }, [category]);

  const totalBagCount = bagItems.reduce((sum, item) => sum + item.quantity, 0);

  const handleBookShootClick = (e: MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    document.dispatchEvent(new CustomEvent("book-shoot", { bubbles: true }));
  };

  const handleAddToBag = (garment: Garment, size: string) => {
    setBagItems((prev) => {
      const idx = prev.findIndex(
        (entry) => entry.garment.id === garment.id && entry.size === size,
      );
      if (idx >= 0) {
        return prev.map((entry, i) =>
          i === idx ? { ...entry, quantity: entry.quantity + 1 } : entry,
        );
      }
      return [...prev, { garment, size, quantity: 1 }];
    });
    setBagOpen(true);
  };

  const handleUpdateQuantity = (garmentId: string, size: string, delta: number) => {
    setBagItems((prev) =>
      prev
        .map((entry) =>
          entry.garment.id === garmentId && entry.size === size
            ? { ...entry, quantity: entry.quantity + delta }
            : entry,
        )
        .filter((entry) => entry.quantity > 0),
    );
  };

  const handleRemoveFromBag = (garmentId: string, size: string) => {
    setBagItems((prev) =>
      prev.filter((entry) => !(entry.garment.id === garmentId && entry.size === size)),
    );
  };

  const handlePullForShoot = (garmentId: string) => {
    setShootGarmentIds((prev) => Array.from(new Set([...prev, garmentId])));
    setShootOpen(true);
  };

  return (
    <div className="min-h-screen bg-[var(--paper)] text-[var(--ink)]">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#1b1a19] text-[var(--paper)]">
        <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-8 px-6 py-4 md:px-12">
          <a
            href="#top"
            className="font-display text-2xl font-medium tracking-tight text-white whitespace-nowrap shrink-0"
          >
            Marcus Atelier
          </a>

          <nav
            aria-label="Primary navigation"
            className="hidden items-center gap-7 text-sm font-medium text-white/75 md:flex"
          >
            <a
              href="#collection"
              className="transition-colors hover:text-white whitespace-nowrap shrink-0"
            >
              Collection
            </a>
            <a
              href="#iridescent-silk"
              className="transition-colors hover:text-white whitespace-nowrap shrink-0"
            >
              Iridescent Silk
            </a>
            <a
              href="#craft"
              className="transition-colors hover:text-white whitespace-nowrap shrink-0"
            >
              Craft
            </a>
            <a
              href="#contact"
              onClick={handleBookShootClick}
              className="transition-colors hover:text-white whitespace-nowrap shrink-0"
            >
              Studio Shoot
            </a>
          </nav>

          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => setBagOpen(true)}
              className="border border-white/20 px-4 py-2 font-mono-tabular text-xs font-medium text-white transition-colors hover:bg-white hover:text-[#1b1a19] whitespace-nowrap shrink-0"
            >
              Bag ({totalBagCount})
            </button>
          </div>
        </div>
      </header>

      <main id="top">
        {/* Section 1: First Page Hero on #1b1a19 with the exact "Book a shoot" button */}
        <section className="bg-[#1b1a19] text-[var(--paper)]">
          <div className="mx-auto grid max-w-[1440px] grid-cols-1 items-stretch lg:grid-cols-12">
            <div className="flex flex-col justify-between px-6 py-12 md:px-12 lg:col-span-6 lg:py-20">
              <div className="space-y-6">
                <div className="flex flex-wrap items-center gap-2 text-xs text-white/65">
                  <span>Autumn / Winter 2026</span>
                  <span aria-hidden="true">·</span>
                  <span>Ready-to-Wear &amp; Studio Pulls</span>
                </div>

                <h1
                  className="font-display text-4xl font-medium leading-[1.04] tracking-tight text-white sm:text-5xl lg:text-6xl"
                  style={{ textWrap: "balance" }}
                >
                  Tailored silhouettes woven in kinetic iridescent silk.
                </h1>

                <p className="max-w-lg text-base leading-relaxed text-white/75">
                  Architectural coats, fluid wool-silk gabardine trousers, and five-harness
                  satin garments engineered to shift colour across every fold. Shop the
                  season or reserve a studio lookbook shoot.
                </p>

                <div className="flex flex-wrap items-center gap-4 pt-3">
                  <a
                    className="btn light"
                    href="#contact"
                    id="book-shoot"
                    onClick={handleBookShootClick}
                  >
                    Book a shoot <b>→</b>
                  </a>

                  <a
                    href="#iridescent-silk"
                    className="inline-flex h-[52px] items-center border border-white/25 px-5 text-sm font-medium text-white transition-colors hover:border-white hover:bg-white/5 whitespace-nowrap shrink-0"
                  >
                    Open Iridescent Silk
                  </a>
                </div>
              </div>

              <div className="mt-12 grid grid-cols-3 gap-6 border-t border-white/10 pt-6 text-xs">
                <div>
                  <p className="text-white/50">Weave</p>
                  <p className="mt-1 font-medium text-white">5-Harness Satin</p>
                </div>
                <div>
                  <p className="text-white/50">Optics</p>
                  <p className="mt-1 font-mono-tabular text-white">300–820 nm</p>
                </div>
                <div>
                  <p className="text-white/50">Edition</p>
                  <p className="mt-1 font-medium text-white">Paris &amp; Kyoto</p>
                </div>
              </div>
            </div>

            <div className="relative min-h-[420px] bg-[#121110] lg:col-span-6 lg:min-h-[640px]">
              {!brokenImages["hero"] ? (
                <img
                  src="/src/assets/images/hero_marcus_campaign_1795341517531.jpg"
                  alt="Models wearing Marcus Atelier iridescent midnight silk trench and slate tailored wool coat"
                  referrerPolicy="no-referrer"
                  onError={() => setBrokenImages((prev) => ({ ...prev, hero: true }))}
                  className="h-full w-full object-cover object-top"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-[#161514] p-12 text-center text-white/70">
                  <span className="font-display text-2xl">Marcus Atelier · AW26 Campaign</span>
                </div>
              )}
              <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/35 to-transparent p-6 md:p-8">
                <p className="text-xs text-white/85">
                  Look 01 · Iridescent Satin Trench &amp; Double-Breasted Slate Overcoat
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Section 2: <WovenCloth variant="iridescent" /> Exact ThreeUI Integration */}
        <section id="iridescent-silk" className="bg-[#05060d] text-white">
          <div className="mx-auto max-w-[1440px] px-6 py-16 md:px-12 lg:py-24">
            <div className="mb-8 flex flex-col justify-between gap-6 md:flex-row md:items-end">
              <div className="max-w-2xl space-y-3">
                <div className="flex items-center gap-2 text-xs text-white/60">
                  <span>Textile Study</span>
                  <span aria-hidden="true">·</span>
                  <span>Iridescent Silk</span>
                  <span aria-hidden="true">·</span>
                  <span>Live Three.js Simulation</span>
                </div>
                <h2
                  className="font-display text-3xl font-medium tracking-tight sm:text-4xl"
                  style={{ textWrap: "balance" }}
                >
                  Five-harness satin under a painted studio environment.
                </h2>
                <p className="text-sm leading-relaxed text-white/70">
                  A thin-film interference layer whose thickness sweeps one full order across the
                  width, so the colour travels over the folds while the woven wordmark stays a
                  tone-on-tone jacquard.
                </p>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => setSilkFullscreen(true)}
                  className="inline-flex h-11 items-center gap-2.5 border border-white/25 px-4 text-xs font-medium text-white transition-colors hover:border-white hover:bg-white/10 whitespace-nowrap shrink-0"
                >
                  <Maximize2 className="h-3.5 w-3.5" />
                  Open Fullscreen Loom
                </button>
              </div>
            </div>

            <div className="h-[460px] w-full border border-white/10 sm:h-[560px] lg:h-[640px]">
              <Scene />
            </div>
          </div>
        </section>

        {/* Section 3: Garment Collection Grid on --paper (#F3F2ED) */}
        <section id="collection" className="bg-[var(--paper)] text-[var(--ink)]">
          <div className="mx-auto max-w-[1440px] px-6 py-16 md:px-12 lg:py-24">
            <div className="flex flex-col justify-between gap-6 border-b border-[var(--line)] pb-8 md:flex-row md:items-end">
              <div className="space-y-2">
                <p className="text-xs text-[var(--muted)]">Autumn / Winter 2026</p>
                <h2 className="font-display text-3xl font-medium tracking-tight sm:text-4xl">
                  The Garment Collection
                </h2>
              </div>

              <div
                role="tablist"
                aria-label="Filter garments by category"
                className="flex flex-wrap items-center gap-1 border border-[var(--line)] bg-white/50 p-1"
              >
                {CATEGORIES.map((cat) => {
                  const active = category === cat;
                  return (
                    <button
                      key={cat}
                      role="tab"
                      aria-selected={active}
                      type="button"
                      onClick={() => setCategory(cat)}
                      className={`px-4 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        active
                          ? "bg-[var(--ink)] text-[var(--paper)]"
                          : "text-[var(--muted)] hover:text-[var(--ink)]"
                      }`}
                    >
                      {cat}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mt-10 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              {filteredGarments.map((garment) => (
                <article
                  key={garment.id}
                  className="group flex flex-col border border-[var(--line)] bg-white/55 transition-transform duration-200 hover:-translate-y-0.5"
                >
                  <button
                    type="button"
                    onClick={() => setSelectedGarment(garment)}
                    className="relative aspect-[4/3] w-full overflow-hidden bg-[#E8E5DC] text-left"
                  >
                    {!brokenImages[garment.id] ? (
                      <img
                        src={garment.image}
                        alt={garment.name}
                        referrerPolicy="no-referrer"
                        onError={() =>
                          setBrokenImages((prev) => ({ ...prev, [garment.id]: true }))
                        }
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.02]"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center bg-[#E8E5DC] p-6 text-center">
                        <span className="font-display text-xl text-[var(--ink)]">
                          {garment.name}
                        </span>
                      </div>
                    )}
                  </button>

                  <div className="flex flex-1 flex-col justify-between p-5">
                    <div>
                      <div className="flex items-center justify-between gap-2 text-xs text-[var(--muted)]">
                        <span>
                          {garment.category} · {garment.material}
                        </span>
                        <span className="text-[var(--blue)] whitespace-nowrap shrink-0">
                          {garment.edition}
                        </span>
                      </div>

                      <div className="mt-2 flex items-baseline justify-between gap-4">
                        <button
                          type="button"
                          onClick={() => setSelectedGarment(garment)}
                          className="text-left text-base font-semibold text-[var(--ink)] hover:underline"
                        >
                          {garment.name}
                        </button>
                        <span className="font-mono-tabular text-sm font-medium text-[var(--ink)] shrink-0">
                          ${garment.price.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    <div className="mt-5 flex items-center justify-between gap-3 border-t border-[var(--line)] pt-4">
                      <button
                        type="button"
                        onClick={() => setSelectedGarment(garment)}
                        className="text-xs font-medium text-[var(--muted)] transition-colors hover:text-[var(--ink)] whitespace-nowrap shrink-0"
                      >
                        Inspect piece
                      </button>

                      <button
                        type="button"
                        onClick={() => handleAddToBag(garment, "M")}
                        className="border border-[var(--ink)] px-3.5 py-2 text-xs font-semibold text-[var(--ink)] transition-colors hover:bg-[var(--ink)] hover:text-[var(--paper)] whitespace-nowrap shrink-0"
                      >
                        Add to bag
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* Section 4: Craftsmanship & Studio Shoot CTA */}
        <section
          id="craft"
          className="border-t border-[var(--line)] bg-[var(--paper)] text-[var(--ink)]"
        >
          <div className="mx-auto max-w-[1440px] px-6 py-16 md:px-12 lg:py-24">
            <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
              <div className="space-y-5 lg:col-span-5">
                <p className="text-xs text-[var(--muted)]">Textile &amp; Production</p>
                <h2
                  className="font-display text-3xl font-medium leading-tight tracking-tight sm:text-4xl"
                  style={{ textWrap: "balance" }}
                >
                  Woven for motion, fitted for the camera.
                </h2>
                <p className="text-sm leading-relaxed text-[var(--muted)]">
                  Every garment in the Marcus Atelier archive is cut to respond to directional
                  studio light. Stylists and private clients can request full rack pulls or
                  in-studio lighting tests ahead of campaign dates.
                </p>
                <div className="pt-2">
                  <a
                    className="btn"
                    href="#contact"
                    onClick={handleBookShootClick}
                  >
                    Book a shoot <b>→</b>
                  </a>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-8 border-t border-[var(--line)] pt-8 sm:grid-cols-3 lg:col-span-7 lg:border-t-0 lg:pt-0">
                <div className="space-y-2 border-t border-[var(--line)] pt-4">
                  <span className="font-mono-tabular text-xs text-[var(--blue)]">01.</span>
                  <h3 className="text-base font-semibold">Five-Harness Satin</h3>
                  <p className="text-sm leading-relaxed text-[var(--muted)]">
                    Long warp floats create uninterrupted specular bands that carry violet,
                    cobalt, and slate across each fold.
                  </p>
                </div>

                <div className="space-y-2 border-t border-[var(--line)] pt-4">
                  <span className="font-mono-tabular text-xs text-[var(--blue)]">02.</span>
                  <h3 className="text-base font-semibold">Architectural Tailoring</h3>
                  <p className="text-sm leading-relaxed text-[var(--muted)]">
                    Full horsehair chest canvases paired with unlined raw silk sleeves for weight
                    without stiffness.
                  </p>
                </div>

                <div className="space-y-2 border-t border-[var(--line)] pt-4">
                  <span className="font-mono-tabular text-xs text-[var(--blue)]">03.</span>
                  <h3 className="text-base font-semibold">Private Shoot Studio</h3>
                  <p className="text-sm leading-relaxed text-[var(--muted)]">
                    Direct editorial pulls and natural-light fitting bays available by
                    appointment for publications and private wardrobes.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Quiet Editorial Footer */}
      <footer id="contact" className="bg-[var(--ink)] text-[var(--paper)]">
        <div className="mx-auto flex max-w-[1440px] flex-col justify-between gap-8 px-6 py-12 md:flex-row md:items-end md:px-12">
          <div className="space-y-2">
            <p className="font-display text-2xl font-medium">Marcus Atelier</p>
            <p className="text-xs text-white/60">
              14 Rue de Turenne, Paris · Nakagyo-ku Textile Archive, Kyoto
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-white/65">
            <a href="#collection" className="hover:text-white">
              Collection
            </a>
            <a href="#iridescent-silk" className="hover:text-white">
              Iridescent Silk
            </a>
            <button
              type="button"
              onClick={() => setShootOpen(true)}
              className="hover:text-white"
            >
              Book a Shoot
            </button>
            <span className="font-mono-tabular text-white/40">© 2026 Marcus Atelier</span>
          </div>
        </div>
      </footer>

      {/* Fullscreen Iridescent Silk Modal */}
      {silkFullscreen && (
        <div
          className="fixed inset-0 z-50 flex flex-col bg-[#05060d]"
          role="dialog"
          aria-modal="true"
          aria-label="Fullscreen Iridescent Silk Loom"
        >
          <div className="flex items-center justify-between border-b border-white/10 px-6 py-4 text-white">
            <div className="flex items-center gap-3 text-xs">
              <span className="font-medium">Woven Cloth · Iridescent Silk</span>
              <span aria-hidden="true" className="text-white/40">
                ·
              </span>
              <span className="text-white/65">Five-harness satin thin-film simulation</span>
            </div>
            <button
              type="button"
              onClick={() => setSilkFullscreen(false)}
              className="inline-flex h-10 items-center gap-2 border border-white/20 px-4 text-xs font-medium text-white transition-colors hover:bg-white hover:text-[#05060d]"
            >
              <X className="h-4 w-4" />
              Close Loom
            </button>
          </div>
          <div className="relative flex-1 min-h-0">
            <Scene />
          </div>
        </div>
      )}

      <BookShootDrawer
        isOpen={shootOpen}
        onClose={() => setShootOpen(false)}
        initialGarmentIds={shootGarmentIds}
      />

      <GarmentDetailModal
        garment={selectedGarment}
        onClose={() => setSelectedGarment(null)}
        onAddToBag={handleAddToBag}
        onPullForShoot={handlePullForShoot}
      />

      <BagDrawer
        isOpen={bagOpen}
        items={bagItems}
        onClose={() => setBagOpen(false)}
        onUpdateQuantity={handleUpdateQuantity}
        onRemove={handleRemoveFromBag}
        onClearBag={() => setBagItems([])}
      />
    </div>
  );
}
