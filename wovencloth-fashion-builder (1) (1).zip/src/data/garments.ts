export type GarmentCategory = "All" | "Outerwear" | "Silk & Shirts" | "Tailoring";

export interface Garment {
  id: string;
  sku: string;
  name: string;
  category: Exclude<GarmentCategory, "All">;
  material: string;
  weaveNote: string;
  price: number;
  image: string;
  sizes: readonly string[];
  edition: string;
  description: string;
}

export const GARMENTS: readonly Garment[] = [
  {
    id: "silk-trench",
    sku: "MA-AW26-01",
    name: "Iridescent Satin Trench",
    category: "Outerwear",
    material: "Five-Harness Silk Satin",
    weaveNote: "300–820nm interference dye",
    price: 1850,
    image: "/src/assets/images/garment_silk_trench_1795341517368.jpg",
    sizes: ["XS", "S", "M", "L", "XL"],
    edition: "Numbered Edition",
    description:
      "Cut from heavyweight five-harness mulberry silk satin whose optical finish shifts from midnight indigo to slate violet across each lapel fold. Finished with horn buckle waist belt and storm welt.",
  },
  {
    id: "wool-overcoat",
    sku: "MA-AW26-02",
    name: "Double-Breasted Slate Overcoat",
    category: "Outerwear",
    material: "Super 140s Wool & Silk",
    weaveNote: "Full-canvas architectural chest",
    price: 2140,
    image: "/src/assets/images/garment_wool_overcoat_1795341520635.jpg",
    sizes: ["XS", "S", "M", "L", "XL"],
    edition: "Atelier Tailored",
    description:
      "Hand-padded peak lapels and a clean, unvented drape in dark mineral slate wool woven with 18% raw silk for quiet structural sheen.",
  },
  {
    id: "jacquard-overshirt",
    sku: "MA-AW26-03",
    name: "Tone-on-Tone Jacquard Overshirt",
    category: "Silk & Shirts",
    material: "Woven Mulberry Jacquard",
    weaveNote: "Raised warp float motif",
    price: 780,
    image: "/src/assets/images/garment_jacquard_overshirt_1795341521948.jpg",
    sizes: ["XS", "S", "M", "L", "XL"],
    edition: "In Stock",
    description:
      "Boxy studio overshirt with concealed mother-of-pearl placket. Raised satin floats catch directional light while the matte ground keeps the silhouette grounded.",
  },
  {
    id: "pleated-trousers",
    sku: "MA-AW26-04",
    name: "Double-Pleat Gabardine Trouser",
    category: "Tailoring",
    material: "Wool-Silk Gabardine",
    weaveNote: "High-twist 310gsm drape",
    price: 690,
    image: "/src/assets/images/garment_pleated_trousers_1795341520735.jpg",
    sizes: ["XS", "S", "M", "L", "XL"],
    edition: "In Stock",
    description:
      "Full-length tailored trouser featuring deep twin front pleats, extended waist tab, and a fluid column leg that breaks cleanly over boots.",
  },
  {
    id: "satin-drape",
    sku: "MA-AW26-05",
    name: "Asymmetric Draped Satin Tunic",
    category: "Silk & Shirts",
    material: "Bias-Cut Iridescent Silk",
    weaveNote: "Liquid single-piece drape",
    price: 1240,
    image: "/src/assets/images/garment_satin_drape_1795341519950.jpg",
    sizes: ["XS", "S", "M", "L"],
    edition: "Limited Run",
    description:
      "Draped directly on the dress form from a continuous panel of iridescent obsidian-plum satin, anchored at the collarbone and falling to an asymmetric hem.",
  },
  {
    id: "studio-jacket",
    sku: "MA-AW26-06",
    name: "Cropped Raw-Silk Studio Blazer",
    category: "Tailoring",
    material: "Slub Raw Silk & Linen",
    weaveNote: "Unlined breathable weave",
    price: 960,
    image: "/src/assets/images/garment_studio_jacket_1795341520984.jpg",
    sizes: ["XS", "S", "M", "L", "XL"],
    edition: "In Stock",
    description:
      "Cropped short-sleeve tailored studio jacket crafted in textured obsidian raw silk with natural slub character and matte horn buttons.",
  },
];
